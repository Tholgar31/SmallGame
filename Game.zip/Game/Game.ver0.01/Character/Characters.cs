﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enemies;


namespace Character
{
    public abstract class Characters
    {
        protected float health, armore, damage, chance_of_crit, health_amount, coins, xp, inc=100;
        protected string name;
        public float level;
        /// <summary>
        /// Метод реализует атаку игрока
        /// </summary>
        /// <param name="enemy"></param>
        public abstract void Attack(Enemy enemy);
        /// <summary>
        /// Метод реализует атаку по игроку
        /// </summary>
        /// <param name="damage"></param>
        public abstract void AttackByEnemy(float damage);
        /// <summary>
        /// Выводит имя перонажа
        /// </summary>
        public abstract string Name { get; }
        /// <summary>
        /// Выводит и добавляет опыт
        /// </summary>
        public abstract float Experience { get; }
        /// <summary>
        /// Выводит уровень персонажа
        /// </summary>
        public abstract float Level { get; }
        /// <summary>
        /// Выводит  показатель брони
        /// </summary>
        public abstract float Armo { get;  }
        /// <summary>
        /// Выводит  показатель урона
        /// </summary>
        public abstract float Dam { get; }
        /// <summary>
        /// Выводит количество денег
        /// </summary>
        public abstract float Coins { get; }
        /// <summary>
        /// Выводит значение здоровья
        /// </summary>
        public abstract float Health { get; }
        /// <summary>
        /// Метод реализует смену опыта и повышение уровня
        /// </summary>
        /// <param name="exp"></param>
        public abstract void Uppening(float exp);
        Random rnd = new Random();
        /// <summary>
        /// Лечение персонажа
        /// </summary>
        /// <param name="heal"></param>
        public abstract void Healing(float heal);
        /// <summary>
        /// Увеличение здоровья
        /// </summary>
        /// <param name="elixir"></param>
        public abstract void ChangeHealthByElixir(float elixir);
        /// <summary>
        /// Смена значения урона
        /// </summary>
        /// <param name="damag"></param>
        public abstract void ChangeDamage(float damag);
        /// <summary>
        /// Смена значения брони
        /// </summary>
        /// <param name="armo"></param>
        public abstract void ChangeArmor(float armo);
        /// <summary>
        /// Выводит количество опыта для следующего уровня
        /// </summary>
        public abstract float XpForNextLevel { get; }
        /// <summary>
        /// Метод реализует получение монет
        /// </summary>
        /// <param name="coin"></param>
        public abstract void GetCoins(float coin);
        /// <summary>
        /// Метод реализует покупку вещей в магазине
        /// </summary>
        /// <param name="price"></param>
        public abstract void Buying(float price);
    }
}
