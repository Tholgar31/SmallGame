﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enemies;

namespace Character
{
    public class Elf : Characters
    {
        int max_health = 500;
        /// <summary>
        /// Конструктор персонажа
        /// </summary>
        public Elf()
        {
            health = 100;
            health_amount = 100;
            armore = 0;
            do { Console.WriteLine("Enter your character name\n"); name = Console.ReadLine(); } while (name == "");
            damage = rnd.Next(2, 6);
            coins = 0;
            level = 1;
            xp = 0;
        }
        Random rnd = new Random();
        public override float Coins
        {
            get
            {
                return coins;
            }
        }

        public override float Level
        {
            get
            {
                return level;
            }
        }

        public override float Armo
        {
            get
            {
                return armore;
            }
        }
        public override float Dam
        {
            get
            {
                return damage;
            }
        }

        public override string Name
        {
            get
            {
                return name;
            }
        }

        public override float Experience
        {
            get
            {
                return xp;
            }
        }

        public override float Health
        {
            get
            {
                return health;
            }
        }
        public override float XpForNextLevel
        {
            get
            {
                return inc;
            }
        }

        /// <summary>
        /// Метод реализует атаку
        /// </summary>
        /// <param name="enemy"> Противник игрока </param>
        public override void Attack(Enemy enemy)
        {

            if (enemy.Health + enemy.Armor - damage <= 0)
            {
                enemy.GetDamage(enemy.Health + enemy.Armor);
            }
            else
            {
                enemy.GetDamage(damage);
            }
        }
        /// <summary>
        /// Метод реализует атаку по игроку
        /// </summary>
        /// <param name="damage"> урон по игроку </param>
        public override void AttackByEnemy(float damage)
        {
            float damaging;
            damaging = damage - armore;
            if (damaging > 0) health -= damaging;
        }
        /// <summary>
        /// Метод реализует смену значения здоровья (эликсиром)
        /// </summary>
        /// <param name="add"> увеличение здоровья игрока </param>
        public override void ChangeHealthByElixir(float add)
        {
            if (health_amount + add > max_health)
            {
                health_amount = 500;
                Console.WriteLine("maximum health score reached: " + health_amount);
                Console.WriteLine("Current health: " + health);
            }
            else
            {
                health += add;
                Console.WriteLine("Current health: " + health);
            }

        }
        /// <summary>
        /// Метод реализует лечение игрока
        /// </summary>
        /// <param name="heal"> показатель на который происходит лечение </param>
        public override void Healing(float heal)
        {
            if (health + heal > health_amount)
            {
                health = health_amount;
            }
            else
            {
                health += heal;
            }
        }
        /// <summary>
        /// Метод повышения опыта
        /// </summary>
        /// <param name="exp"> опыт за убийство противников </param>
        public override void Uppening(float exp)
        {
            if (xp + exp >= inc)
            {
                xp = 0;
                level++;
                inc += 300;
                health_amount += 15;
                damage += 5;
                armore += 2;
            }
            else { xp += exp; }
        }

        public override void ChangeDamage(float damag)
        {
            damage += damag;
        }

        public override void ChangeArmor(float armo)
        {
            armore += armo;
        }
        public override void GetCoins(float coin)
        {
            coins += coin;
        }

        public override void Buying(float price)
        {
            coins -= price;
        }
    }
}
