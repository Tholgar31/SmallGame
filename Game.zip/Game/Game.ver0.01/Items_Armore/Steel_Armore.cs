﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Items_Armore
{
    public class Steel_Armore : Itemss
    {
        public Steel_Armore()
        {
            name = "Steel armor";
            armore_indic = 5;
            cost_indic = 4;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float Arm
        {
            get
            {
                return armore_indic;
            }
        }
    }
}
