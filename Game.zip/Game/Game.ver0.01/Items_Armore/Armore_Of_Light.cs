﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Items_Armore
{
   public class Armore_Of_Light : Itemss
    {
        public Armore_Of_Light()
        {
            name = "Armor of Light";
            armore_indic = 10;
            cost_indic = 15;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float Arm
        {
            get
            {
                return armore_indic;
            }
        }
    }
}
