﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Items_Armore
{
    public class Iron_Armore:Itemss
    {
        public Iron_Armore()
        {
            name = "Iron armor"; 
            armore_indic = 3;
            cost_indic = 2;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float Arm
        {
            get
            {
                return armore_indic;
            }
        }
    }
}
