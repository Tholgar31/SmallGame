﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elixir
{
   public class Elixir_Of_Increase : Items
    {
        public Elixir_Of_Increase()
        {
            name = "Increase of health reserve";
            health_indic = 15;
            cost_indic = 10;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float Hel
        {
            get
            {
                return health_indic;
            }
        }
    }
}
