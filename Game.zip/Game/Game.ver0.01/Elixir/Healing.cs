﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elixir
{
  public  class Healing : Items
    {
        public Healing()
        {
            name = "Healing elixir";
            health_indic = 25;
            cost_indic = 9;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float Hel
        {
            get
            {
                return health_indic;
            }
        }
    }
}
