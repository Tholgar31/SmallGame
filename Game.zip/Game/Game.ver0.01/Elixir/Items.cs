﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elixir
{
    public abstract class Items
    {
        protected float health_indic, cost_indic;
        protected string name;
        public abstract string Name { get; }
        public abstract float Cost { get; }
        public abstract float Hel { get; }
    }
}
