﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bows
{
   public class Battle_bow:Bow
    {
        public Battle_bow()
        {
            name = "Battle bow";
            damage_indic = 12;
            cost_indic = 3;
        }

        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
