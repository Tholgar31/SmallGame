﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bows
{
    public class Bow_of_Light:Bow
    {
        public Bow_of_Light()
        {
            name = "Bow of Light";
            damage_indic = 12;
            cost_indic = 3;
        }

        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
