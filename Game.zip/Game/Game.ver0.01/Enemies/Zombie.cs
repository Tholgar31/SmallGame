﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enemies
{
    public class Zombie:Enemy
    {
        public Zombie()
        {
            name = "Zombie";
            health = 15;
            armor = 1;
            damaging = 5;
            xp = 7;
            coins = 2;
        }
        public override float Armor
        {
            get
            {
                return armor;
            }
        }
        //посмотреть имя
        public override string Name
        {
            get
            {
                return name;
            }
        }
        //атаковать противника
        public override float Atack
        {
            get
            {
                return rnd.Next(1, 7);
            }
        }
        //посмотреть здоровье
        public override float Health
        {
            get
            {
                return health;
            }
        }
        //получить урон
        public override void GetDamage(float dam)
        {
            if (health + armor - dam <= 0)
            {
                health = 0;
            }
            else
            {
                health = health + armor - dam;
            }
        }
        //Опыт, который начислится игроку
        public override float Exper
        {
            get
            {
                return xp;
            }
        }
        public override float Money
        {
            get
            {
                return coins;
            }
        }
    }
}
