﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enemies
{
    public abstract class Enemy
    {
        protected float health, damaging, armor, xp, coins;
        protected string name;
        public Random rnd = new Random();
        //просмотр имени
        public abstract string Name { get; }
        //атака противника
        public abstract float Atack { get; }
        //посмотреть здоровье
        public abstract float Health { get; }
        //получить урон
        public abstract void GetDamage(float dam);
        public abstract float Exper { get; }
        public abstract float Money { get; }
        public abstract float Armor { get; }
    }
}
