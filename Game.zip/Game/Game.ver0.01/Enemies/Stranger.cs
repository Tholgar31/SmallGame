﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enemies
{
    public class Stranger: Enemy
    {
        Random rand = new Random();
        public Stranger()
        {
            name = "Stranger";
            health = 18;
            armor = 3;
            xp = 12;
            coins = rand.Next(2, 5);
        }
        //просмотр имени
        public override string Name
        {
            get
            {
                return name;
            }
        }
        //Урон по противнику
        public override float Atack
        {
            get
            {
                return rnd.Next(2, 6);
            }
        }
        //Посмотреть здоровье
        public override float Health
        {
            get
            {
                return health;
            }

        }

        public override float Exper
        {
            get
            {
                return xp;
            }
        }

        public override float Money
        {
            get
            {
                return coins;
            }
        }
        //получить урон
        public override void GetDamage(float dam)
        {
            if (health + armor - dam <= 0)
            {
                health = 0;
            }
            else
            {
                health = health + (armor - dam);
            }
        }
        public override float Armor
        {
            get
            {
                return armor;
            }
        }
    }
}
