﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enemies
{
   public class Rat : Enemy
    {
        //конструктор персонажа
        public Rat()
        {
            name = "Rat";
            health = 10;
            armor = 0;
            xp = 5;
            coins = 2;
        }
        //просмотр имени
        public override string Name
        {
            get
            {
                return name;
            }
        }
        //Урон по противнику
        public override float Atack
        {
            get
            {
                return rnd.Next(1,5);
            }
        }
        //Посмотреть здоровье
        public override float Health
        {
            get
            {
                return health;
            }
           
        }

        public override float Exper
        {
            get
            {
                return xp;
            }
        }

        public override float Money
        {
            get
            {
                return coins;
            }
        }

        public override float Armor
        {
            get
            {
                return armor;
            }
        }

        //получить урон
        public override void GetDamage(float dam)
        {
            if (health - dam <= 0)
            {
                health = 0;
            }
            else
            {
                health -= dam;
            }
        }
    }
}
