﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enemies
{
    public class Dark_dragon:Enemy
    {
        Random rand = new Random();
        public Dark_dragon()
        {
            name = "Dark dragon";
            health = 25;
            armor = 2;
            xp = 10;
            coins = rand.Next(2, 4);
            damaging=rnd.Next(2, 5);
        }
        public override float Armor
        {
            get
            {
                return armor;
            }
        }
        //просмотр имени
        public override string Name
        {
            get
            {
                return name;
            }
        }
        //Урон по противнику
        public override float Atack
        {
            get
            {
                return damaging;
            }
        }
        //Посмотреть здоровье
        public override float Health
        {
            get
            {
                return health;
            }

        }
        public void ChangeDamage()
        {
            damaging = damaging * 3;
        }
        public override float Exper
        {
            get
            {
                return xp;
            }
        }

        public override float Money
        {
            get
            {
                return coins;
            }
        }
        //получить урон
        public override void GetDamage(float dam)
        {
            if (health + armor - dam <= 0)
            {
                health = 0;
            }
            else
            {
                health = health + armor - dam;
            }
        }
    }
}
