﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axes
{
    public class Axe_Of_Light : Item
    {
        public Axe_Of_Light()
        {
            name = "Axe of Ligth";
            damage_indic = 19;
            cost_indic = 18;

        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
