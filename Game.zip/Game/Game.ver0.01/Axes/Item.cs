﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axes
{
    public abstract class Item
    {
        protected float damage_indic, cost_indic;
        protected string name;
        public abstract string Name{ get;}
        public abstract float Cost { get; }
        public abstract float damag { get; }
    }
}
