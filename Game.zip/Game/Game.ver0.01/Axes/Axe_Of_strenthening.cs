﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axes
{
    public class Axe_Of_strenthening : Item
    {
        public Axe_Of_strenthening()
        {
            name = "Axe of strenthening";
            damage_indic = 17;
            cost_indic = 10;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
