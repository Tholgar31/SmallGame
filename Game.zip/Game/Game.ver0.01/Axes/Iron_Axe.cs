﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axes
{
    public class Iron_Axe : Item
    {
        public Iron_Axe()
        {
            name = "Iron axe";
            damage_indic = 12;
            cost_indic = 3;
        }

        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
