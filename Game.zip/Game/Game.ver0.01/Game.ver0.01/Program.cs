﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axes;
using Character;
using Elixir;
using Items_Armore;
using Swords;
using Enemies;
using Bows;


namespace Game.ver0._01
{
    class Program
    {
        public static int k = 0;
        //Array of monsters for Hall
        public static Enemy[] en = { new Rat(), new Blood_sucker(), new Bats(), new Skeleton() };
        public static int change, barrel = 0;
        private static int BattleChance(ref Characters character, Enemy[] ene, int amount)
        {
            Random rnd = new Random();
            for (int i = 0; i < amount; i++)
            {
                Console.WriteLine("Your enemy is: " + ene[i].Name);
                Console.WriteLine("It's health: " + ene[i].Health);
                Console.WriteLine("It's damage: " + ene[i].Atack);
            }
            Console.WriteLine("\nYour characteristics: ");
            Characteristics(ref character);
            Console.WriteLine("\nWhat would you do?\n");
            string txt = "Fight      1\n" +
                         "Run        2\n";
            Console.WriteLine(txt);
            int path;
            do
            {
                Console.WriteLine("Choose the way\n");
            } while (!int.TryParse(Console.ReadLine(), out path) || path < 1 || path > 2);
            if (path == 1)
            {
                return 1;
            }
            else
            {
                Console.WriteLine("You are running from enemies. After running far away, you catch your breath, but notice that you have been wounded.");
                character.AttackByEnemy(rnd.Next(5, 21));
                Console.WriteLine("Your health now: {0}", character.Health);
                return 0;
            }
        }
        /// <summary>
        /// Метод описывает сражение с противником. Игрок и компьютер поочередно наносят урон друг другу
        /// </summary>
        /// <param name="character"> персонаж игрока </param>
        /// <param name="en"> монстры на которых игрок наткнулся</param>
        public static void Battle(ref Characters character, Enemy[] ene, int amount)
        {
            Random r = new Random();
            //This is just a conseption of the battle
            //The queue isn't good
            //It works but really strange
            //Need to make a standartization of the battle and phrases
            int que = r.Next(0, 1), foe;
            if (que == 0)
            {
                Console.WriteLine("Ha-ha! Fortune is yours! You attack first.\n");
                if (amount > 1)
                {
                    do
                    {
                        Console.WriteLine("There are some enemies.");
                        for (int i = 0; i < amount; i++)
                        {
                            Console.WriteLine((i + 1) + ")" + ene[i].Name);
                        }
                        Console.WriteLine("Who do you want to attack?");
                        do
                        {
                            Console.WriteLine("Choose the enemy?");
                        } while (!int.TryParse(Console.ReadLine(), out foe) || foe > amount + 1);
                        foe--;
                        character.Attack(ene[foe]);
                        if (ene[foe].Health <= 0)
                        {
                            for (int i = foe; i < amount - 1; i++)
                            {
                                ene[i] = ene[i + 1];
                            }
                            character.GetCoins(ene[amount - 1].Money);
                            character.Uppening(ene[amount - 1].Exper);
                            amount--;
                        }
                        for (int i = 0; i < amount; i++)
                        {
                            Console.WriteLine("Your enemy is {0}. It's health: {1}", ene[i].Name, ene[i].Health);
                        }
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                        for (int i = 0; i < amount; i++)
                        {
                            character.AttackByEnemy(ene[i].Atack);
                            Console.WriteLine("You were attacked! Your health: " + character.Health);
                        }
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                        if (character.Health <= 0) BadEnding();
                    } while (amount != 0 && character.Health > 0);
                }
                else
                {
                    if (amount == 1)
                    {
                        foe = 0;
                        Console.WriteLine("There is only one enemy. Attack!\n");
                        do
                        {
                            Console.WriteLine(ene[foe].Name);
                            Console.WriteLine("You attacked {0}", ene[foe].Name);
                            foe = 0;
                            character.Attack(ene[foe]);
                            if (ene[foe].Health <= 0)
                            {
                                character.GetCoins(ene[foe].Money);
                                Console.WriteLine("You see corpse of your enemy. You won and get {0} coins and {1} experience", ene[foe].Money, ene[foe].Exper);
                                character.Uppening(ene[foe].Exper);
                                amount--;
                            }
                            else
                            {
                                Console.WriteLine("Your enemy: " + ene[foe].Name + ". It's health: {0}", ene[foe].Health);
                                Console.WriteLine("Press Enter...");
                                Console.ReadKey();
                                character.AttackByEnemy(ene[foe].Atack);
                                Console.WriteLine("You were attacked! Your health: " + character.Health);
                                Console.WriteLine("Press Enter...\n\n");
                                Console.ReadKey();
                                if (character.Health <= 0) { BadEnding(); }
                            }


                        } while (amount != 0 && character.Health > 0);
                    }
                }
            }
            else
            {
                if (amount > 1)
                {
                    Console.WriteLine("Goddam! They took us by suprise. Defend!");
                    do
                    {
                        Console.WriteLine("There are some enemies.");
                        for (int i = 0; i < amount; i++)
                        {
                            Console.WriteLine((i + 1) + ")" + ene[i].Name);
                        }
                        for (int i = 0; i < amount; i++)
                        {
                            character.AttackByEnemy(ene[i].Atack);
                            Console.WriteLine("You were attacked by {0}! Your health: {1}", ene[i].Name, character.Health);
                        }
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                        if (character.Health <= 0)
                        {
                            BadEnding();
                        }
                        else
                        {
                            for (int i = 0; i < amount; i++)
                            {
                                Console.WriteLine((i + 1) + ")" + ene[i].Name);
                            }
                            do
                            {
                                Console.WriteLine("Choose the enemy.");
                            } while (!int.TryParse(Console.ReadLine(), out foe) || foe > amount + 1);
                            foe--;
                            character.Attack(ene[foe]);
                            if (ene[foe].Health <= 0)
                            {
                                for (int i = foe; i < amount - 1; i++)
                                {
                                    ene[i] = ene[i + 1];
                                }
                                character.GetCoins(ene[amount - 1].Money);
                                character.Uppening(ene[amount - 1].Exper);
                                amount--;
                            }
                            if (amount != 0) Console.WriteLine("Your enemies still alive!");
                        }
                    } while (amount != 0 && character.Health > 0);
                }
                else
                {
                    if (amount == 1)
                    {
                        foe = 0;
                        do
                        {
                            Console.WriteLine("There is only one enemy.");
                            Console.WriteLine("Goddam! Enemy attacked you first. Defend!");
                            Console.WriteLine("Your enemy: " + ene[foe].Name + ". It's health: {0}", ene[foe].Health);
                            character.AttackByEnemy(ene[foe].Atack);
                            Console.WriteLine("You were attacked.");
                            Console.WriteLine("Your health: {0}", character.Health);
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                            if (character.Health <= 0) { BadEnding(); }
                            Console.WriteLine("You attacked {0}.", ene[foe].Name);
                            character.Attack(ene[foe]);
                            if (ene[foe].Health <= 0)
                            {
                                character.GetCoins(ene[foe].Money);
                                Console.WriteLine("You see corpse of your enemy. You won and get {0} coins and {1} experience", ene[foe].Money, ene[foe].Exper);
                                character.Uppening(ene[foe].Exper);
                                amount--;
                            }
                            else
                            {
                                Console.WriteLine("Your enemy: " + ene[foe].Name + ". It's health: {0}", ene[foe].Health);
                                Console.WriteLine("Press Enter...\n\n");
                                Console.ReadKey();
                            }
                        } while (amount != 0 && character.Health > 0);
                    }
                }
            }

        }
        /// <summary>
        /// Метод создает противников игрока
        /// </summary>
        /// <param name="character"> Персонаж игрока </param>
        public static void GenerationOfEnemyForHall(ref Characters character)
        {
            //There is a problem. Generation of enemy - really strange process. 
            //Here we should make a dicision how it shoud work. 
            //Because for any level of chacter should be needed amount of enemies. Also
            //Here must be specialization based on type of level.
            Random rnd = new Random();
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(1, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, en.Length);
                ene[i] = en[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        /// <summary>
        /// Метод реализует поход по залу
        /// </summary>
        /// <param name="character"> Персонаж игрока </param>
        public static int GoToHall(ref Characters character)
        {
            int r = 0;
            int way;
            Random rnd = new Random();
            do
            {
                Console.WriteLine("You're entering dark great hall. There are some noises around. You see some barrels near the wall.\n" +
                    "What would you do?");
                string txt = "Search for something in barrels    1\n" +
                             "Search for enemies in the dark     2\n" +
                             "Go back                            3\n";
                Console.WriteLine(txt);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
                if (way == 1)
                {
                    if (barrel < 5)
                    {
                        if (rnd.Next(0, 100) >= 60)
                        {
                            Console.WriteLine("You found some thing in barrel. Look! This is coins!");
                            int coin = rnd.Next(2, 5);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();

                        }
                        else
                        {
                            Console.WriteLine("Sorry. This barrel was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                    if (barrel >= 5)
                    {

                        Console.WriteLine("Sorry there aren't more barrels.\n\n");
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                    }
                }
                if (way == 2)
                {
                    if (rnd.Next(0, 100) > 50)
                    {
                        Console.WriteLine("You found someone in the dark. Prepare for battle.\n\n");
                        GenerationOfEnemyForHall(ref character);
                        r = -1;
                        return r;
                    }
                }
                if (way == 3)
                {
                    Console.WriteLine("We are going back.\n\n\n");
                    Console.WriteLine("Press Enter...\n\n");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }
        public static Enemy[] enForTunnel = { new Bats(), new Blood_sucker(), new Skeleton(), new Wild_ork(), new Stranger(), new Rat() };
        public static void GenerationOfEnemyForTunnel(ref Characters character)
        {
            Random rnd = new Random();
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(1, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, enForTunnel.Length);
                ene[i] = enForTunnel[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        /// <summary>
        /// Метод описывает поход по туннелю
        /// </summary>
        /// <param name="character"> Персонаж игрока </param>
        public static int GoToTunnel(ref Characters character)
        {
            int r = 0;
            barrel = 0; int way;
            Random rnd = new Random();
            do
            {
                Console.WriteLine("You're entering dark tunnel. There are some noises around. You see some barrels near the wall. You took a torch from the wall" +
                    ".\n Small cirle of space illuminated by it.\n" +
                    "What would you do?");
                string txt = "Search for something in barrels    1\n" +
                             "Search for enemies in the dark     2\n" +
                             "Go back                            3\n";
                Console.WriteLine(txt);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
                if (way == 1)
                {
                    if (barrel < 7)
                    {
                        if (rnd.Next(0, 100) >= 70)
                        {
                            Console.WriteLine("You found some thing in barrel. Look! This is coins!");
                            int coin = rnd.Next(2, 5);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();

                        }
                        else
                        {
                            Console.WriteLine("Sorry. This barrel was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                    if (barrel >= 7)
                    {

                        Console.WriteLine("Sorry there aren't more barrels.\n\n");
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                    }
                }
                if (way == 2)
                {
                    if (rnd.Next(0, 100) > 45)
                    {
                        Console.WriteLine("You found someone in the dark. Prepare for battle.\n\n");
                        GenerationOfEnemyForTunnel(ref character);
                        r = -1;
                        return r;
                    }
                }
                if (way == 3)
                {
                    Console.WriteLine("We are going back.\n\n\n");
                    Console.WriteLine("Press Enter... \n\n");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }
        public static Enemy[] eneForCave = { new Pirate(), new Demon_of_the_deep(), new A_thousand_tentacles(), new Water_elemental(), new Drowned_sailor() };
        public static void GenerationOfEnemyForCave(ref Characters character)
        {
            Random rnd = new Random();
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(2, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, eneForCave.Length);
                ene[i] = eneForCave[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        public static int GoToCave(ref Characters character)
        {
            int r = 0;
            Random rnd = new Random();
            barrel = 0; int way;
            string txt = "Search for something in chests     1\n" +
                         "Try to touch the water with stick  2\n" +
                         "Go back                            3\n";
            do
            {
                Console.WriteLine("You are entering dark cave. Near walls you see some chests. Maybe there can be something interesting?\n The cave has a smooth slope that ends in the water. Here you see some tentacles. Maybe you should touch them with a stick?");
                Console.WriteLine("\n\n" + txt);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
                if (way == 1)
                {
                    if (barrel < 4)
                    {
                        if (rnd.Next(0, 100) >= 80)
                        {
                            Console.WriteLine("You found some thing in chest. Look! This is coins!");
                            int coin = rnd.Next(4, 7);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadLine();

                        }
                        else
                        {
                            Console.WriteLine("Sorry. This chest was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                    if (barrel >= 4)
                    {

                        Console.WriteLine("Sorry there aren't more chests.\n\n");
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                    }
                }

                if (way == 2)
                {
                    if (rnd.Next(0, 100) > 45)
                    {
                        Console.WriteLine("Tentacles hide in the water. The water started to bubble and bubbles began to rise from the bottom. Prepare for battle.\n\n");
                        GenerationOfEnemyForCave(ref character);
                        r = -1;
                        return r;
                    }
                }
                if (way == 3)
                {
                    Console.WriteLine("We are going back.\n\n\n");
                    Console.WriteLine("Press Enter... \n\n");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }

        public static void GenerationOfEnemyForSpiderLair(ref Characters character)
        {
            Enemy[] eneForSpiderLair = { new Cave_spider(), new Black_spider(),
                                          new Plague_Spider(), new Spider_drone(),
                                          new Spider_queen(), new Venomous_spider(),
                                          new Ice_Spider() };
            Random rnd = new Random();
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(2, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, eneForSpiderLair.Length);
                ene[i] = eneForSpiderLair[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        public static int GoToSpiderLair(ref Characters character)
        {
            int r = 0;
            Random rnd = new Random();
            barrel = 0; int way;
            string txt = "Try to open chests        1\n" +
                          "Try to pass the lair      2\n" +
                          "Go back                   3\n";
            do
            {
                Console.WriteLine("You are entering dark lair that entangled in cobwebs. The sounds if thousands of paws moving come from there. \nYou feel the gaze of many thousands of eyes on you.");
                Console.WriteLine("In the dark you can see some chests but should you open them?");

                Console.WriteLine(txt);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
                if (way == 1)
                {
                    if (barrel >= 6)
                    {
                        Console.WriteLine("There aren't more chests.");
                        Console.WriteLine("Press Enter...");
                        Console.ReadKey();
                    }
                    else
                    {
                        if (rnd.Next(0, 100) > 30)
                        {
                            Console.WriteLine("As soon as You started to open the chest a giant spider jumped down from the ceiling. You need to fight.");
                            GenerationOfEnemyForSpiderLair(ref character);
                        }
                        if (rnd.Next(0, 100) >= 50)
                        {
                            Console.WriteLine("You found some thing in chest. Look! This is coins!");
                            int coin = rnd.Next(4, 7);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                        }
                        else
                        {
                            Console.WriteLine("Sorry. This chest was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                }
                if (way == 2)
                {
                    Console.WriteLine("You are trying to pass the lair. You are slowly treading on the bones of less fortunate travelers.");
                    if (rnd.Next(0, 100) > 35)
                    {
                        Console.WriteLine("Goddam! Something jumped from the ceiling behind Your back.");
                        GenerationOfEnemyForSpiderLair(ref character);
                        r = -1;
                        return r;
                    }
                }
                if (way == 3)
                {
                    Console.WriteLine("You are going back...");
                    Console.WriteLine("Press Enter...");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }
        public static void GenerationOfEnemyForDragonLair(ref Characters character)
        {
            Random rnd = new Random();
            Enemy[] enForDragonLair = { new Dark_dragon(), new Storm_dragon(), new Gold_dragon(), new Emerald_dragon() };
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(2, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, enForDragonLair.Length);
                ene[i] = enForDragonLair[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        public static void TalkingWithDragon(ref Characters character)
        {
            int way; k = 0;
            Console.WriteLine("You carefully approach the slepping dragon. Suddenly it raises it's head.\n" +
                              "As soos as You saw that great creture cold stickly sweat appeared on the skin" +
                              "Great lizard yawned widely showing all it's teeth.");
            Console.WriteLine("What do You want, stranger. - asked dragon");
            string[] txt = { "Go away You vile creature. I'm great hero!", "Hello gorgeous creature. I want to pass to get out of the dungeon.", "I'm {0} and i'm the hero. I want to pass this dungeon and reach untold riches that stored in the Greatest library." };
            int j = 1;
            for (int i = 0; i < txt.Length; i++)
            {
                Console.WriteLine(j + ")" + "   " + txt[i], character.Name);
                j++;
            }
            do
            {
                Console.WriteLine("Choose the answer");
            } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
            if (way == 1)
            {
                Console.WriteLine("You, little worm. - dragon got up and let out a terrible roar - See the power of dragons");
                GenerationOfEnemyForDragonLair(ref character);
                k = -1;
                return;
            }
            if (way == 2)
            {
                Console.WriteLine("What's that? Flattery? - dragon got up - What do you want mortal?");
                txt = new string[] { "No-no. I'm just really shocked by Your strength.", "I want to reach knowledge that hided in Great library." };
                j = 1;
                for (int i = 0; i < txt.Length; i++)
                {
                    Console.WriteLine(j + ")" + txt[i]);
                    j++;
                }
                do
                {
                    Console.WriteLine("Choose the answer");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                if (way == 1)
                {
                    Console.WriteLine("I'll give you another chance. - said dragon - Say, why are you here? - dragon looks angry.");
                    txt = new string[] { "I've came just to see your greatness and power.", "I've came for knowledge." };
                    j = 1;
                    for (int i = 0; i < txt.Length; i++)
                    {
                        Console.WriteLine(j + ")" + txt[i]);
                        j++;
                    }
                    do
                    {
                        Console.WriteLine("Choose the answer");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);

                    if (way == 1)
                    {
                        Console.WriteLine("You - little mortal worm. Behold the furious anger!!! - dragon let out a terrible roar and spat out a stream of flame." +
                            "\n Other dragons woke up and answered with flames. Prepare for battle.");
                        GenerationOfEnemyForDragonLair(ref character);
                        k = -1;
                        return;
                    }
                    else
                    {
                        Console.WriteLine("That knowledge is really dangerous. Do You think you are ready?");
                        txt = new string[] { "Yes ", "Ready to what?" };
                        j = 1;
                        for (int i = 0; i < txt.Length; i++)
                        {
                            Console.WriteLine(j + ")" + txt[i]);
                            j++;
                        }
                        do
                        {
                            Console.WriteLine("Choose the answer");
                        } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                        if (way == 2)
                        {
                            Console.WriteLine("This knowledge is really powerful and that one who will possess them will be able to change the world. \nSo I will ask again. Are you ready? ");
                            txt = new string[] { "Yes, I'm ready.", "No, I think that is really big risk." };
                            j = 1;
                            for (int i = 0; i < txt.Length; i++)
                            {
                                Console.WriteLine(j + ")" + txt[i]);
                                j++;
                            }
                            do
                            {
                                Console.WriteLine("Choose the answer");
                            } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                            if (way == 1)
                            {
                                Console.WriteLine("You are really self-confident. That can be a vice. But we will help you.");
                                Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                                Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                                character.ChangeDamage(20);
                                Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                                Console.WriteLine("Dragon the guardian lets you pass the lair.");
                                Console.WriteLine("\n\nPress Enter...");
                                Console.ReadKey();
                                return;
                            }
                            if (way == 2)
                            {
                                Console.WriteLine("You are hesitant. That can be a vice. But we will help you.");
                                Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                                Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                                character.ChangeDamage(20);
                                Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                                Console.WriteLine("But I'll give you extra. - guardian looked at the dragon. The flying drago passes you  an object from the other paw.");
                                Console.WriteLine("That armor belonged to the greatest hero of ancient. It may be useful.");
                                character.ChangeArmor(10);
                                Console.WriteLine("Dragon the guardian lets you pass the lair.");
                                Console.WriteLine("\n\nPress Enter...");
                                Console.ReadKey();
                                return;
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("That knowledge is really dangerous. Do You think you are ready?");
                    txt = new string[] { "Yes ", "Ready to what?" };
                    j = 1;
                    for (int i = 0; i < txt.Length; i++)
                    {
                        Console.WriteLine(j + ")" + txt[i]);
                        j++;
                    }
                    do
                    {
                        Console.WriteLine("Choose the answer");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                    if (way == 2)
                    {
                        Console.WriteLine("This knowledge is really powerful and that one who will possess them will be able to change the world. \nSo I will ask again. Are you ready? ");
                        txt = new string[] { "Yes, I'm ready.", "No, I think that is really big risk." };
                        j = 1;
                        for (int i = 0; i < txt.Length; i++)
                        {
                            Console.WriteLine(j + ")" + txt[i]);
                            j++;
                        }
                        do
                        {
                            Console.WriteLine("Choose the answer");
                        } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                        if (way == 1)
                        {
                            Console.WriteLine("You are really self-confident. That can be a vice. But we will help you.");
                            Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                            Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                            character.ChangeDamage(20);
                            Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                            Console.WriteLine("Dragon the guardian lets you pass the lair.");
                            Console.WriteLine("\n\nPress Enter...");
                            Console.ReadKey();
                            return;

                        }
                        if (way == 2)
                        {
                            Console.WriteLine("You are hesitant. That can be a vice. But we will help you.");
                            Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                            Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                            character.ChangeDamage(20);
                            Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                            Console.WriteLine("But I'll give you extra. - guardian looked at the dragon. The flying drago passes you  an object from the other paw.");
                            Console.WriteLine("That armor belonged to the greatest hero of ancient. It may be useful.");
                            character.ChangeArmor(10);
                            Console.WriteLine("Dragon the guardian lets you pass the lair.");
                            Console.WriteLine("\n\nPress Enter...");
                            Console.ReadKey();
                            return;
                        }
                    }
                }
            }
            if (way == 3)
            {
                Console.WriteLine("That knowledge is really dangerous. Do You think you are ready?");
                txt = new string[] { "Yes ", "Ready to what?" };
                j = 1;
                for (int i = 0; i < txt.Length; i++)
                {
                    Console.WriteLine(j + ")" + txt[i]);
                    j++;
                }
                do
                {
                    Console.WriteLine("Choose the answer");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                if (way == 2)
                {
                    Console.WriteLine("This knowledge is really powerful and that one who will possess them will be able to change the world. \nSo I will ask again. Are you ready? ");
                    txt = new string[] { "Yes, I'm ready.", "No, I think that is really big risk." };
                    j = 1;
                    for (int i = 0; i < txt.Length; i++)
                    {
                        Console.WriteLine(j + ")" + txt[i]);
                        j++;
                    }
                    do
                    {
                        Console.WriteLine("Choose the answer");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
                    if (way == 1)
                    {
                        Console.WriteLine("You are really self-confident. That can be a vice. But we will help you.");
                        Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                        Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                        character.ChangeDamage(20);
                        Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                        Console.WriteLine("Dragon the guardian lets you pass the lair.");
                        Console.WriteLine("\n\nPress Enter...");
                        Console.ReadKey();
                        return;
                    }
                    if (way == 2)
                    {
                        Console.WriteLine("You are hesitant. That can be a vice. But we will help you.");
                        Console.WriteLine("One dragon flew off from his rookery holding something in it's paws.");
                        Console.WriteLine("We will give you this sword. This is very powerful ancient artifact.");
                        character.ChangeDamage(20);
                        Console.WriteLine("You get ancient artifact - Sword of heroes.\n Your damage increased.");
                        Console.WriteLine("But I'll give you extra. - guardian looked at the dragon. The flying drago passes you  an object from the other paw.");
                        Console.WriteLine("That armor belonged to the greatest hero of ancient. It may be useful.");
                        character.ChangeArmor(10);
                        Console.WriteLine("Dragon the guardian lets you pass the lair.");
                        Console.WriteLine("\n\nPress Enter...");
                        Console.ReadKey();
                        return;
                    }
                }
            }
        }
        public static int GoToDragonLair(ref Characters character)
        {
            int r = 0;
            Random rnd = new Random();
            barrel = 0; int way;
            string text = "Try to open chest                 1\n" +
                         "Try to talk with dragon-guardian  2\n" +
                         "Attack dragon-guardian            3\n" +
                         "Go back                           4\n";
            do
            {
                Console.WriteLine("You entered great lair of dragons. The lair is really huge. Lizards flying under the ceiling, sleeping in the holes. One of them lying on the\n" +
                    "road that leads to the exit from dungeon. As soon as You entered the lair there were several chests right there.\n" +
                    " Dragons are really dangerous enemies. Be careful, because they are the greatest creatures of magic. If you will\n" +
                    "fight with them then Boss will have more points of health, damage and armore\n" +
                    "but the experience for killing the boss will be doubled.");
                Console.WriteLine(text);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 4);
                if (way == 1)
                {
                    if (barrel >= 4)
                    {
                        if (rnd.Next(0, 100) > 85)
                        {
                            Console.WriteLine("You found some thing in chest. Look! This is coins!");
                            int coin = rnd.Next(4, 7);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                        }
                        else
                        {
                            Console.WriteLine("Sorry. This chest was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                    else
                    {
                        Console.WriteLine("Sorry. There aren't more chests.\n\n\n");
                        Console.WriteLine("Press Enter...\n\n");
                        Console.ReadKey();
                    }
                }
                if (way == 2)
                {
                    TalkingWithDragon(ref character);
                    return r;
                }
                if (way == 3)
                {
                    Console.WriteLine("As soon as You rushed at the lizard, the dragon let out a terrible roar\n" +
                        " that rolled throught the lair, waking everyone up.");
                    GenerationOfEnemyForDragonLair(ref character);
                    k = -1;
                    r = -1;
                    return r;
                }
                if (way == 4)
                {
                    Console.WriteLine("You are going back...");
                    Console.WriteLine("\n\nPress Enter...");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }
        public static Enemy[] eneForCemestry = { new Zombie(), new Plague_zombie(), new Vampire(), new Vampire_prince(), new Dark_ghost(), new White_ghost(), new Skeleton(), new Plague_Spider() };
        public static void GenerationOfEnemyForCemestry(ref Characters character)
        {
            Random rnd = new Random();
            Enemy[] ene = new Enemy[100];
            int foe; int amount, road;
            amount = rnd.Next(2, 3);
            for (int i = 0; i < amount; i++)
            {
                foe = rnd.Next(0, eneForCemestry.Length);
                ene[i] = eneForCemestry[foe];
            }
            road = BattleChance(ref character, ene, amount);
            if (road == 1) Battle(ref character, ene, amount);
            ene = null;
        }
        public static int GoToCemestry(ref Characters character)
        {
            int r = 0;
            Random rnd = new Random();
            barrel = 0; int way;
            string txt = "Search for something in barrels     1\n" +
                           "Try to cross cemetry                2\n" +
                           "Go back                             3\n";
            do
            {
                Console.WriteLine("You came out of the dungeon and found yourself in the cemetery. \nThere is fog everywhere. You see some shadows that walking among graves.");
                Console.WriteLine(txt);
                do
                {
                    Console.WriteLine("Choose the way");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 3);
                if (way == 1)
                {
                    if (barrel < 7)
                    {
                        if (rnd.Next(0, 100) > 75)
                        {
                            Console.WriteLine("You found some thing in chest. Look! This is coins!");
                            int coin = rnd.Next(4, 7);
                            Console.WriteLine("You get {0} ", coin + " coins");
                            character.GetCoins(coin);
                        }
                        else
                        {
                            Console.WriteLine("Sorry. This chest was empty.\n\n\n");
                            Console.WriteLine("Press Enter...\n\n");
                            Console.ReadKey();
                        }
                        barrel++;
                    }
                    else
                    {
                        Console.WriteLine("Sorry. There aren't more barrels.");
                        Console.WriteLine("Press Enter...");
                        Console.ReadKey();
                    }
                }
                if (way == 2)
                {
                    int t = 0;
                    do
                    {
                        Console.WriteLine("You are moving through the cemetery. In the fog, you see shadows.");
                        if (rnd.Next(0, 100) > 55)
                        {
                            t = -1;
                            Console.WriteLine("Somebody is approaching you. Prepare for battle.");
                            GenerationOfEnemyForCemestry(ref character);
                            r = -1;
                        }
                    } while (t == 0);
                    return r;
                }
                if (way == 3)
                {
                    Console.WriteLine("You are going back...");
                    Console.WriteLine("Press Enter...");
                    Console.ReadKey();
                    return r;
                }
            } while (true);
        }
        public static string[] txt = { "Go to Hall", "Go to Tunnel", "Go to Cave", "Go to Spider lair", "Go to Dragon lair", "Go to Cemestry" };
        public static int leng = txt.Length;
        /// <summary>
        /// Метод реализует саму игру 
        /// </summary>
        /// <param name="character"> Персонаж игрока </param>
        public static void GoToDungeonGame(ref Characters character)
        {
            int r = 0;
            Random rnd = new Random();
            int way;
            for (int i = 0; i < leng; i++)
            {
                Console.WriteLine((i + 1) + ")     " + txt[i]);
            }
            do
            {
                Console.WriteLine("Choose the way");
            } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 6);
            change = way - 1;
            way--;
            if (txt[way] == "Go to Hall")
            {
                r = GoToHall(ref character);

            }
            if (txt[way] == "Go to Tunnel")
            {
                r = GoToTunnel(ref character);
            }
            if (txt[way] == "Go to Cave")
            {
                r = GoToCave(ref character);
            }
            if (txt[way] == "Go to Spider lair")
            {
                r = GoToSpiderLair(ref character);
            }
            if (txt[way] == "Go to Dragon lair")
            {
                r = GoToDragonLair(ref character);
            }
            if (txt[way] == "Go to Cemestry")
            {
                r = GoToCemestry(ref character);
            }
            if (r == -1)
            {
                for (int i = change; i < leng - 1; i++)
                {
                    txt[i] = txt[i + 1];
                }
                leng--;
            }
        }
        /// <summary>
        /// Метод описывает путешествие по подземелью
        /// </summary>
        /// <param name="character"> персонаж игрока </param>        
        public static void GoToDungeon(ref Characters character)
        {
            Console.WriteLine("You're entering ancient Dungeon. There are a lots of bones and this disgusting smell around You.\n");
            GoToDungeonGame(ref character);
        }
        /// <summary>
        /// Метод представляющий магазин, где герой может купить различное оружие, эликсиры и броню
        /// </summary>
        /// <param name="character"> персонаж игрока </param>
        public static int a = 0, ar = 0, s = 0;
        public static Item[] axe = { new Iron_Axe(), new Steel_Axe(), new Axe_Of_strenthening(), new Axe_Of_Light(), new Axe_Of_Darkness() };
        public static Item_sword[] sword = { new Iron_Sword(), new Steel_Sword(), new Sword_of_Eldra(), new Sword_of_Lurnak() };
        public static Itemss[] armor = { new Iron_Armore(), new Steel_Armore(), new Armore_Of_Light(), new Armore_Of_Darkness() };
        public static Items[] elixir = { new Healing(), new Elixir_Of_Increase() };
        public static void GoToShop(ref Characters character)
        {
            Console.WriteLine("Hello stranger. Have a look at my assortment");
            Console.WriteLine("Choose anything you want. And... prepare your money of course. Ha-ha!");
            string txt = "Axes      1\n" +
                         "Swords    2\n" +
                         "Elixirs   3\n" +
                         "Armor     4\n" +
                         "Back      5\n";
            string agrement = "Yes    1\n" +
                              "No     2\n";
            Console.WriteLine(txt);
            int way, key;
            do
            {
                Console.WriteLine("Choose that you want to buy");
            } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 5);
            if (way == 1)
            {
                if (a != axe.Length)
                {
                    for (int i = 0; i < axe.Length - a; i++)
                    {
                        Console.WriteLine((i + 1) + ") " + "Name of item: " + axe[i].Name);
                        Console.WriteLine("Cost of item: " + axe[i].Cost);
                    }
                    Console.WriteLine("Which one do You want?");
                    do
                    {
                        Console.WriteLine("Choose the weapon");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > axe.Length - a);
                    way--;
                    Console.WriteLine("Oh-oh-ho. Nice choose. But... Let me see if you have enough money.");
                    Console.WriteLine("Your budget: " + character.Coins);
                    if (character.Coins >= axe[way].Cost)
                    {
                        Console.WriteLine("Yeah, I see. Do you want to buy it?");
                        do { Console.WriteLine(agrement); } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 2);
                        if (key == 1)
                        {
                            character.Buying(axe[way].Cost);
                            character.ChangeDamage(axe[way].damag);
                            Console.WriteLine("Yeah! Thank you for visiting.");
                            Console.ReadKey();
                            for (int i = way; i < axe.Length - 1; i++)
                            {
                                axe[i] = axe[i + 1];
                            }
                            a++;
                        }
                        else
                        {
                            Console.WriteLine("As You wish.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("I'm very sorry but I'm not banker. And I can't give you credit.");
                    }
                    return;
                }
                else
                {
                    Console.WriteLine("My assortment is not infinite.");
                    Console.WriteLine("Press Enter...\n\n");
                    Console.ReadKey();
                    return;
                }
            }
            if (way == 2)
            {
                if (s != sword.Length)
                {
                    for (int i = 0; i < sword.Length - s; i++)
                    {
                        Console.WriteLine((i + 1) + ") " + "Name of item: " + sword[i].Name);
                        Console.WriteLine("Cost of item: " + sword[i].Cost);
                    }
                    Console.WriteLine("Which one do You want?");
                    do
                    {
                        Console.WriteLine("Choose the weapon");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > sword.Length - s);
                    way--;
                    Console.WriteLine("Oh-oh-ho. Nice choose. But... Let me see if you have enough money.");
                    Console.WriteLine("Your budget: " + character.Coins);
                    if (character.Coins >= sword[way].Cost)
                    {
                        Console.WriteLine("Yeah, I see. Do you want to buy it?");
                        Console.WriteLine(agrement);
                        do { Console.WriteLine(agrement); } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 2);
                        if (key == 1)
                        {
                            character.Buying(sword[way].Cost);
                            character.ChangeDamage(sword[way].damag);
                            Console.WriteLine("Yeah! Thank you for visiting.");
                            for (int i = way; i < sword.Length - 1; i++)
                            {
                                sword[i] = sword[i + 1];
                            }
                            s++;
                        }
                        else
                        {
                            Console.WriteLine("As You wish.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("I'm very sorry but I'm not banker. And I can't give you credit.");
                    }
                    return;
                }
                else
                {
                    Console.WriteLine("My assortment is not infinite.");
                    Console.WriteLine("Press Enter...\n\n");
                    Console.ReadKey();
                    return;
                }
            }
            if (way == 3)
            {
                for (int i = 0; i < elixir.Length; i++)
                {
                    Console.WriteLine((i + 1) + ") " + "Name of item: " + elixir[i].Name);
                    Console.WriteLine("Cost of item: " + elixir[i].Cost);
                }
                Console.WriteLine("Which one do You want?");
                do
                {
                    Console.WriteLine("Choose the weapon");
                } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > elixir.Length);
                way--;
                Console.WriteLine("Oh-oh-ho. Nice choose. But... Let me see if you have enough money.");
                Console.WriteLine("Your budget: " + character.Coins);
                if (character.Coins >= elixir[way].Cost)
                {
                    Console.WriteLine("Yeah, I see. Do you want to buy it?");
                    do { Console.WriteLine(agrement); } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 2);
                    if (key == 1)
                    {
                        if (elixir[way] is Elixir_Of_Increase)
                        {
                            character.Buying(elixir[way].Cost);
                            character.ChangeHealthByElixir(elixir[way].Hel);
                        }
                        if (elixir[way] is Healing)
                        {
                            character.Buying(elixir[way].Cost);
                            character.Healing(elixir[way].Hel);
                        }
                        Console.WriteLine("Yeah! Thank you for visiting.");
                    }
                    else
                    {
                        Console.WriteLine("As You wish.");
                    }
                }
                else
                {
                    Console.WriteLine("I'm very sorry but I'm not banker. And I can't give you credit.");
                }
                return;
            }
            if (way == 4)
            {
                if (ar != armor.Length)
                {
                    for (int i = 0; i < armor.Length - ar; i++)
                    {
                        Console.WriteLine((i + 1) + ") " + "Name of item: " + armor[i].Name);
                        Console.WriteLine("Cost of item: " + armor[i].Cost);
                    }
                    Console.WriteLine("Which one do You want?");
                    do
                    {
                        Console.WriteLine("Choose the weapon");
                    } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > armor.Length - ar);
                    way--;
                    Console.WriteLine("Oh-oh-ho. Nice choose. But... Let me see if you have enough money.");
                    Console.WriteLine("Your budget: " + character.Coins);
                    if (character.Coins >= armor[way].Cost)
                    {
                        Console.WriteLine("Yeah, I see. Do you want to buy it?");
                        do { Console.WriteLine(agrement); } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 2);
                        if (key == 1)
                        {
                            character.Buying(armor[way].Cost);
                            character.ChangeArmor(armor[way].Arm);
                            Console.WriteLine("Yeah! Thank you for visiting.");
                            for (int i = way; i < armor.Length - 1; i++)
                            {
                                armor[i] = armor[i + 1];
                            }
                            ar++;
                        }
                        else
                        {
                            Console.WriteLine("As You wish.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("I'm very sorry but I'm not banker. And I can't give you credit.");
                    }
                    return;
                }
                else
                {
                    Console.WriteLine("My assortment is not infinite.");
                    Console.WriteLine("Press Enter...\n\n");
                    Console.ReadKey();
                    return;
                }
            }

            if (way == 5)
            {
                Console.WriteLine("As You wish. Come back when you will have enough money.");
                return;
            }
        }
        public static void Inventory(ref Characters character)
        {

        }
        public static void Characteristics(ref Characters character)
        {
            Console.WriteLine("Your character name:               " + character.Name);
            Console.WriteLine("Your character health:             " + character.Health);
            Console.WriteLine("Your character armor:              " + character.Armo);
            Console.WriteLine("Your character damage:             " + character.Dam);
            Console.WriteLine("Your character coins:              " + character.Coins);
            Console.WriteLine("Your character level:              " + character.Level);
            Console.WriteLine("Your character current experience: " + character.Experience);
            Console.WriteLine("Needed experience for next level:  " + character.XpForNextLevel);
            Console.WriteLine("\n\n\n\n Press Enter to continue");
            Console.ReadLine();
        }
        /// <summary>
        /// Метод описывает надписы, меню действий, которые ему доступны
        /// </summary>
        /// <param name="character"> персонаж игрока </param>
        public static void Interface(ref Characters character)
        {
            do
            {
                string menu =
                    "Go to the dungeon                 1\n" +
                    "Go to shop                        2\n" +
                    "Characteristics of the character  3\n" +
                    "Exit                              4\n";
                Console.WriteLine(menu);
                int key;
                do
                {
                    Console.WriteLine("Choose your way");
                } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 4);
                if (key == 1) { GoToDungeon(ref character); }
                if (key == 2) { GoToShop(ref character); }
                if (key == 3) { Characteristics(ref character); }
                if (key == 4) { Environment.Exit(13); }
                if (leng == 0) { Ending(ref character); }
            } while (character.Health > 0);
        }
        public static void CreatingCharacter()
        {
            Console.WriteLine("Choose your character, stranger, and hurry up to meet the adventure");
            string charactes = "Human     1\n" +
                                          "Eld       2\n" +
                                          "Dwarf     3\n" +
                                          "Ork       4";
            Console.WriteLine(charactes);
            int key;
            /*do
            {
                Console.WriteLine("Choose your character");
            } while (!int.TryParse(Console.ReadLine(), out key) || key < 1 || key > 4);
            Characters character = null;
            if (key == 1) { character = new Human(); }
            if (key == 2) { character = new Elf(); }
            if (key == 3) { character = new Dwarf(); }
            if (key == 4) { character = new Ork(); }
            Interface(ref character);*/
            Characters character = new Ork();
            Inventory(ref character);
        }
        static void Main()
        {
            //Идет приветствие. Выбор персонажа.
            //Написать фразы в файл и оттуда попеременно считывать. А то долго и нудно.
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Hello stranger. Welcome to our dangeon. There are a lot of enemies, so be careful.");
            CreatingCharacter();
        }
        /// <summary>
        /// Метод описывает окончание игры в случае плохого окончания, то есть смерти персонажа игрока.
        /// </summary>
        public static void BadEnding()
        {
            Console.WriteLine("That was intresting journey but Your way is over. Maybe You should try again?");
            Console.WriteLine("Press Enter...\n\n");
            Console.ReadKey();
            Environment.Exit(15);
        }
        public static void Ending(ref Characters character)
        {
            int way;
            Console.WriteLine("After all locations that You visited, all enemies, You came out to the greatest mountain. \n" +
                              "A large stone staircase leads to the top. As you climb higher and higher, you notice a bright glow. After you see the flash, the storm begins." +
                              "As soon as you reached top of mountain You saw acient oldman.");
            Console.WriteLine("You reached me. - said oldman - I see that You are strong enough to change the world... But You should choose the side.");
            string txt = "1)   Side of Light\n" +
                         "2)   Side of Darkness";
            Console.WriteLine(txt);
            do
            {
                Console.WriteLine("Choose the side");
            } while (!int.TryParse(Console.ReadLine(), out way) || way < 1 || way > 2);
            if (way == 1)
            {
                Console.WriteLine("As soon as You choosed the side storm become stronger. Lightning struck the ground in the place where oldman stayed. \n" +
                                  "The old man was enveloped in a glow. After that insted of oldman You saw the greates demon.");
                Console.WriteLine("I'm the spirit of Light and Darkness. If You will kill me, You will be the Master of the World and all knowledge will belong to you.\n" +
                                  "Defend!");
                Enemy[] ene = { new Old_man_Darkness() };
                Battle(ref character, ene, ene.Length);
                Console.WriteLine("Your enemy lying in front of you. You haven't noticed when storm end. Now everywhere sun shining and birds singing." +
                                  "But lightning struck the place where you were standing. You stucked on the top of mountain.\n" +
                                  "-You can't leave this place until another hero kill you, but you can explore that knowledge.-\n" +
                                  "The voice muted and Great library appeared in front of You. ");
                Console.WriteLine("\n\nPress Enter to finish the game.");
                Console.ReadKey();
                PostScriptum();
            }
            if (way == 2)
            {
                Console.WriteLine("As soon as You choosed the side storm ended. But lightning struck the ground in the place where oldman stayed. \n" +
                                  "He become higher. His clothes turned white and behind back You saw wings. You saw the greatest angel.\n" +
                                  "I'm angel and my name is Light Keeper. If you kill me, You will be the Overlord of this World.");
                Enemy[] ene = { new Old_man_Darkness() };
                Battle(ref character, ene, ene.Length);
                Console.WriteLine("Your enemy lying in front of you. You haven't noticed when storm end. Now everywhere sun shining and birds singing.\n" +
                                  "But You feel blood lust in Your veins. Anger blurs your eyes. A little bit more and you will lose your mind, but you can keep it.\n" +
                                  "-Now you are dark lord - said voice - your empire of Evil will coquer all neighbors and even further.\n" +
                                  "It'll be strongest empire that World saw and it will stay untile it is destroyed by another hero.-\n" +
                                  "Voice muted and you go down the stairs.\n\n\n");
                Console.WriteLine("Press Enter to finish the game.");
                Console.ReadKey();
                PostScriptum();
            }
        }
        public static void PostScriptum()
        {
            Console.Clear();
            Console.WriteLine("Thank you for passing this game. That was my first experience in programming so huge programm so don't be very strict.\n" +
                              "I can say thank you for everyone for help.");
            Console.WriteLine("Press Enter...");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}