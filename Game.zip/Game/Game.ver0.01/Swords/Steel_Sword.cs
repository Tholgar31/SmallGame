﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swords
{
   public class Steel_Sword : Item_sword
    {
        public Steel_Sword()
        {
            name = "Steel sword";
            damage_indic = 15;
            cost_indic = 15;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
