﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swords
{
    public class Iron_Sword : Item_sword
    {
        public Iron_Sword()
        {
            name = "Iron sword";
            damage_indic = 10;
            cost_indic = 5;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }

        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
