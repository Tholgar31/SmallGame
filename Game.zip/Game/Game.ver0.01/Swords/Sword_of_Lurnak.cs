﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swords
{
   public class Sword_of_Lurnak : Item_sword
    {
        public Sword_of_Lurnak()
        {
            name = "Lurnak's sword";
            damage_indic = 23;
            cost_indic = 30;
        }
        public override string Name
        {
            get
            {
                return name;
            }
        }
        public override float Cost
        {
            get
            {
                return cost_indic;
            }
        }
        public override float damag
        {
            get
            {
                return damage_indic;
            }
        }
    }
}
